package com.example.callrate

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import java.util.Locale

class CallScreenService : AccessibilityService() {
    private var windowManager: WindowManager? = null
    private var badge: TextView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString()?.lowercase(Locale.ROOT) ?: return
        // 앱 패키지명이 기기/버전에 따라 다를 수 있어 카카오 계열 앱 이벤트만 우선 처리합니다.
        if (!pkg.contains("kakao")) {
            hideBadge()
            return
        }
        val root = rootInActiveWindow ?: return
        val texts = ArrayList<String>()
        collectText(root, texts)
        val allText = texts.joinToString(" ")
        val amount = findAmount(allText)
        val minutes = findDuration(allText)
        if (amount != null && minutes != null && minutes > 0) {
            val hourly = amount.toDouble() * 60.0 / minutes
            showBadge("콜 분석  ${String.format("%,d", amount)}원 / ${minutes}분\n시간당 약 ${String.format("%,.0f", hourly)}원")
        } else {
            showBadge("콜 화면 감지 중\n금액·소요시간을 읽지 못했습니다")
        }
    }

    private fun collectText(node: AccessibilityNodeInfo, out: MutableList<String>) {
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        for (i in 0 until node.childCount) node.getChild(i)?.let { child ->
            collectText(child, out)
            child.recycle()
        }
    }

    private fun findAmount(text: String): Long? {
        val match = Regex("(?<![0-9])([0-9]{1,3}(?:,[0-9]{3})+|[0-9]{4,6})\\s*원").find(text) ?: return null
        return match.groupValues[1].replace(",", "").toLongOrNull()
    }

    private fun findDuration(text: String): Int? {
        val hourMin = Regex("([0-9]+)\\s*시간\\s*([0-9]+)?\\s*분?").find(text)
        if (hourMin != null) {
            val h = hourMin.groupValues[1].toIntOrNull() ?: 0
            val m = hourMin.groupValues[2].toIntOrNull() ?: 0
            return h * 60 + m
        }
        val min = Regex("([0-9]+)\\s*분").find(text) ?: return null
        return min.groupValues[1].toIntOrNull()
    }

    private fun showBadge(message: String) {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        if (badge == null) {
            badge = TextView(this).apply {
                textSize = 15f
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundColor(0xDD202124.toInt())
                setPadding(24, 16, 24, 16)
            }
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 120 }
            windowManager?.addView(badge, params)
        }
        badge?.text = message
    }

    private fun hideBadge() {
        badge?.let { view -> try { windowManager?.removeView(view) } catch (_: Exception) {} }
        badge = null
    }

    override fun onInterrupt() { hideBadge() }
    override fun onDestroy() { hideBadge(); super.onDestroy() }
}
