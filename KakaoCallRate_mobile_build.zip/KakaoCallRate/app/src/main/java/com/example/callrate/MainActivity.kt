package com.example.callrate

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        layout.addView(TextView(this).apply {
            text = "콜 시간당 단가 분석기\n\n카카오 T 콜 화면의 글자를 읽어 시간당 단가를 계산합니다. 자동 접수 기능은 없습니다.\n\n1) 다른 앱 위에 표시 권한 허용\n2) 접근성 설정에서 ‘콜 화면 분석’ 켜기\n3) 카카오 T 콜 화면을 열어 테스트"
            textSize = 17f
        })
        layout.addView(Button(this).apply {
            text = "다른 앱 위에 표시 권한 설정"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "접근성 권한 설정"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(layout)
    }
}
